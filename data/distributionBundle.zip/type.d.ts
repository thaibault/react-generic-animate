import { ForwardRefExoticComponent, ReactElement, RefAttributes } from 'react';
import { TransitionProps } from 'react-transition-group/Transition';
import { StaticWebComponent as StaticBaseWebComponent } from 'web-component-wrapper/type';
export type GenericAnimateProps = Partial<TransitionProps<HTMLElement | undefined>>;
export interface GenericAnimateComponent<Type> extends Omit<ForwardRefExoticComponent<GenericAnimateProps>, 'propTypes'>, StaticBaseWebComponent<Type> {
    (props: (GenericAnimateProps & RefAttributes<HTMLDivElement | HTMLSpanElement>)): ReactElement;
}
